package com.example.mobile_uts

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
